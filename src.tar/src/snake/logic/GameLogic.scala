package snake.logic
import snake.logic.GameLogic._
import scala.collection.mutable.ListBuffer
import engine.random.RandomGenerator

/** To implement Snake, complete the TODOs below.
  *
  * If you need additional files,
  * please also put them in the snake package.
  */
class GameLogic(val random: RandomGenerator,
                val gridDims : Dimensions) {


  private val snakeBody: ListBuffer[Point] = ListBuffer.empty[Point]
  snakeBody += Point(2, 0)
  snakeBody += Point(1, 0)
  snakeBody += Point(0, 0)
  private var snakeDirection: Direction = East()
  private var currentDirection: Direction = East()
  private var directionChangedOnce: Boolean = false
  private var reverseFlag: Boolean = false
  private var applePosition: Point = generateApple()
  private var growthTimes: Int = 0
  private val gameStateHistory: ListBuffer[GameState] = ListBuffer(newGameState())

  def gameOver: Boolean = {
    if (snakeCollidedItself(snakeBody)) true
    else false
  }

  def newGameState(): GameState = {
    val newSnakeBody = ListBuffer.empty[Point] ++ snakeBody
    val newSnakeDirection = snakeDirection
    val newApplePosition = applePosition
    val newGrowthTimes = growthTimes

    new GameState(
      newSnakeBody,
      newSnakeDirection,
      newApplePosition,
      newGrowthTimes
    )
  }

  def step(): Unit = {
    if (reverseFlag) {
      bringPreviousState()
    }
    else {
      if (!gameOver) {
        move()
        eatApple()
        directionChangedOnce = false
        gameStateHistory.prepend(newGameState())
      }
    }
  }

  // TODO implement me
  def changeDir(d: Direction): Unit = {
    if (d != snakeDirection && currentDirection.opposite != d) {
      snakeDirection = d
    }
  }

  // TODO implement me
  def getCellType(p: Point): CellType = {
    if (p == snakeBody.head) {
      SnakeHead(snakeDirection)
    } else if (snakeBody.contains(p)) {
      val distance = snakeBody.indexOf(p).toFloat / (snakeBody.length - 1)
      SnakeBody(distance)
    } else if (p == applePosition) {
      Apple()
    } else {
      Empty()
    }
  }

  private def generateApple(): Point = {
    val available4Apple: ListBuffer[Point] = new ListBuffer[Point]()

    for (i <- gridDims.allPointsInside) {
      if (getCellType(i) == Empty()) {
        available4Apple.append(i)
      }
    }
    if (available4Apple.isEmpty) {
      return null
    }
    val locateApple = random.randomInt(available4Apple.length)
    val applePosition = available4Apple(locateApple)
    applePosition
  }

  private def move(): Unit = {
    currentDirection = snakeDirection
    var newHead: Point = snakeBody.head + snakeDirection.theVector

    if (newHead.x == gridDims.width) newHead = Point(newHead.x - gridDims.width, newHead.y)
    else if (newHead.x == -1) newHead = Point(newHead.x + gridDims.width, newHead.y)
    else if (newHead.y == gridDims.height) newHead = Point(newHead.x, newHead.y - gridDims.height)
    else if (newHead.y == -1) newHead = Point(newHead.x, newHead.y + gridDims.height)

    if (growthTimes == 0) snakeBody -= snakeBody.last
    else growthTimes -= 1

    snakeBody.prepend(newHead)
  }

  private def eatApple(): Unit = {

    if (appleIsFound()) {
      growthTimes += 3
      applePosition = generateApple()

    }
    else return
  }

  private def appleIsFound(): Boolean = {
    if (snakeBody.contains(applePosition)) {
      true
    } else {
      false
    }
  }

  def snakeCollidedItself(snake: ListBuffer[Point]): Boolean = {
    if (snake.tail.contains(snake.head)) true
    else false
  }

  // TODO implement me
  def setReverse(r: Boolean): Unit = {
    reverseFlag = r
  }

  def bringPreviousState(): Unit = {
    if (gameStateHistory.size > 1) {
      gameStateHistory.remove(0)
      val prevState: GameState = gameStateHistory.head
      snakeBody.clear()
      snakeBody ++= prevState.snakeBody
      snakeDirection = prevState.snakeDirection
      applePosition = prevState.applePosition
      growthTimes = prevState.growthTimes
    }
  }
}
class GameState(
                 val snakeBody: ListBuffer[Point],
                 val snakeDirection: Direction,
                 val applePosition: Point,
                 val growthTimes: Int
               ) {
}
/** GameLogic companion object */
object GameLogic {

  val FramesPerSecond: Int = 5 // change this to increase/decrease speed of game

  val DrawSizeFactor = 1.0 // increase this to make the game bigger (for high-res screens)
  // or decrease to make game smaller

  // These are the dimensions used when playing the game.
  // When testing the game, other dimensions are passed to
  // the constructor of GameLogic.
  //
  // DO NOT USE the variable DefaultGridDims in your code!
  //
  // Doing so will cause tests which have different dimensions to FAIL!
  //
  // In your code only use gridDims.width and gridDims.height
  // do NOT use DefaultGridDims.width and DefaultGridDims.height
  val DefaultGridDims
  : Dimensions =
  Dimensions(width = 25, height = 25) // you can adjust these values to play on a different sized board
}